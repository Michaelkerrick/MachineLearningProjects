A simple project for automatic stock analysis and recommendation based on clustering, written in Python. It uses actual data obtained using Yahoo Finance API and ticker data from NASDAQ.

There are numerous ways to vastly improve it, including better feature engineering and feature selection for clustering, improvements in overall cluster analysis and recomendations, etc. 
